import React, { useState, useEffect } from 'react';
import './index.css';
function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isCartVisible, setIsCartVisible] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    quantity: '',
    image: '',
    category: 'Fruits',
  });
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('/db.json');
        const data = await response.json();
        setProducts(data.products);
      } catch (error) {
        console.error('Error fetching the products:', error);
      }
    };
    fetchProducts();
  }, []);
  const toggleCartVisibility = () => {
    setIsCartVisible((prev) => !prev);
  };
  const addToCart = (product) => {
    if (product.quantity <= 0) {
      alert(`${product.name} is out of stock!`);
      return;
    }
    setCart((prevCart) => {
      const existingProduct = prevCart.find((item) => item.id === product.id);

      if (existingProduct) {
        if (existingProduct.cartQuantity < product.quantity) {
          return prevCart.map((item) =>
            item.id === product.id
              ? { ...item, cartQuantity: item.cartQuantity + 1 }
              : item
          );
        } else {
          alert(`No more ${product.name} available!`);
          return prevCart;
        }
      } else {
        return [...prevCart, { ...product, cartQuantity: 1 }];
      }
    });

    setProducts((prevProducts) =>
      prevProducts.map((item) =>
        item.id === product.id ? { ...item, quantity: item.quantity - 1 } : item
      )
    );
  };

  const removeFromCart = (id) => {
    const productToRemove = cart.find((item) => item.id === id);
    if (productToRemove) {
      setCart((prevCart) => prevCart.filter((item) => item.id !== id));
      setProducts((prevProducts) =>
        prevProducts.map((item) =>
          item.id === id ? { ...item, quantity: item.quantity + productToRemove.cartQuantity } : item
        )
      );
    }
  };

  const deleteProduct = (id) => {
    setProducts((prevProducts) => prevProducts.filter((product) => product.id !== id));
  };

  const editProduct = (id) => {
    const productToEdit = products.find((product) => product.id === id);
    const newName = prompt('Enter new name:', productToEdit.name);
    const newPrice = prompt('Enter new price:', productToEdit.price);
    const newQuantity = prompt('Enter new quantity:', productToEdit.quantity);
    const newImage = prompt('Enter new image URL:', productToEdit.image);

    if (newName && newPrice && newQuantity && newImage) {
      setProducts((prevProducts) =>
        prevProducts.map((product) =>
          product.id === id
            ? {
                ...product,
                name: newName,
                price: parseFloat(newPrice),
                quantity: parseInt(newQuantity, 10),
                image: newImage,
              }
            : product
        )
      );
    }
  };

  const openAddProductModal = () => {
    setIsModalVisible(true);
  };

  const closeAddProductModal = () => {
    setIsModalVisible(false);
    setNewProduct({ name: '', price: '', quantity: '', image: '', category: 'Fruits' });
  };

  const handleAddNewProduct = () => {
    const { name, price, quantity, image, category } = newProduct;
    if (!name || !price || !quantity || !image || !category) {
      alert('Please fill all fields');
      return;
    }

    const newProductItem = {
      id: products.length + 1,
      name,
      price: parseFloat(price),
      quantity: parseInt(quantity, 10),
      image,
      category,
    };

    setProducts((prevProducts) => [...prevProducts, newProductItem]);
    closeAddProductModal();
  };

  const filteredProducts = products.filter(
    (product) =>
      (selectedCategory === 'All' || product.category === selectedCategory) &&
      product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = ['All', 'Fruits', 'Vegetables', 'Groceries', 'Snacks', 'Drinks', 'Beautyrelated'];

  const totalAmount = cart.reduce((total, item) => total + item.price * item.cartQuantity, 0).toFixed(2);

  const handleProceedToPay = () => {
    if (cart.length === 0) {
      alert('Your cart is empty. Please add items to the cart before proceeding.');
    } else {
      alert(`Proceeding to payment with total amount ₹${totalAmount}`);
      // After payment is complete, empty the cart
      setCart([]);
    }
  };

  return (
    <div className="app">
      <header className="header-container">
        <h1>Welcome to Our Grocery Store</h1>
        <div className="search-container">
          <input
            type="text"
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>
        <button className="cart-toggle-button" onClick={toggleCartVisibility}>
          {isCartVisible ? 'Close Cart' : 'View Cart'}
        </button>
        <button className="new-product-button" onClick={openAddProductModal}>
          Add New Product
        </button>
      </header>

      <div className="category-buttons">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={selectedCategory === category ? 'active' : ''}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="product-list">
        {filteredProducts.map((product) => (
          <div key={product.id} className="product-item">
            <img src={product.image} alt={product.name} className="grocery-image" />
            <h2>{product.name}</h2>
            <p>Price: ₹{product.price.toFixed(2)}</p>
            <p>Available: {product.quantity}</p>
            <div className="product-actions">
              <button
                onClick={() => addToCart(product)}
                className={`add-button ${product.quantity <= 0 ? 'out-of-stock' : ''}`}
                disabled={product.quantity <= 0}
              >
                Add to Cart
              </button>
              <button onClick={() => editProduct(product.id)} className="edit-button">
                Edit
              </button>
              <button onClick={() => deleteProduct(product.id)} className="delete-button">
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {isCartVisible && (
        <div className={`cart ${isCartVisible ? 'visible' : ''}`}>
          <h2 className="cart-title">Your Cart</h2>
          {cart.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="cart-item">
                <img src={item.image} alt={item.name} className="cart-image" />
                <div className="cart-details">
                  <p>{item.name}</p>
                  <p>Price: ₹{item.price.toFixed(2)}</p>
                  <p>Quantity: {item.cartQuantity}</p>
                </div>
                <button
                  className="delete-button"
                  onClick={() => removeFromCart(item.id)}
                >
                  Remove
                </button>
              </div>
            ))
          )}
          <div className="cart-total">
            Total: ₹{totalAmount}
          </div>
          <button className="proceed-to-pay" onClick={handleProceedToPay}>
            Proceed to Pay
          </button>
        </div>
      )}

      {isModalVisible && (
        <div className="modal">
          <div className="modal-content">
            <h2>Add New Product</h2>
            <input
              type="text"
              placeholder="Name"
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
            />
            <input
              type="number"
              placeholder="Price"
              value={newProduct.price}
              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
            />
            <input
              type="number"
              placeholder="Quantity"
              value={newProduct.quantity}
              onChange={(e) => setNewProduct({ ...newProduct, quantity: e.target.value })}
            />
            <input
              type="text"
              placeholder="Image URL"
              value={newProduct.image}
              onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
            />
            <select
              value={newProduct.category}
              onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
            >
              <option value="Fruits">Fruits</option>
              <option value="Vegetables">Vegetables</option>
              <option value="Groceries">Groceries</option>
              <option value="Snacks">Snacks</option>
              <option value="Drinks">Drinks</option>
              <option value="Beautyrelated">Beautyrelated</option>
            </select>
            <button onClick={handleAddNewProduct}>Add Product</button>
            <button onClick={closeAddProductModal}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
