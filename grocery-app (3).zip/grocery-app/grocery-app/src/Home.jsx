import React, { useState, useEffect } from 'react';
import './index.css';

function App() {
  // States for login and signup
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isSignup, setIsSignup] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All'); // New state for category

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('/db.json');
        const data = await response.json();
        setProducts(data.products);
      } catch (error) {
        console.error('Error fetching the products:', error);
      }
    };
    fetchProducts();
  }, []);

  const handleLogin = () => {
    // Simulate a login (in real life, authenticate with backend)
    if (username && password) {
      setIsLoggedIn(true);
    } else {
      alert('Please enter valid credentials!');
    }
  };

  const handleSignup = () => {
    // Simulate signup (in real life, store user data in the backend)
    if (username && password) {
      alert('Signup Successful!');
      setIsSignup(false);
    } else {
      alert('Please fill in all fields!');
    }
  };

  const addToCart = (product) => {
    if (product.quantity <= 0) {
      alert(`${product.name} is out of stock!`);
      return;
    }

    setCart((prevCart) => {
      const existingProduct = prevCart.find((item) => item.id === product.id);
      if (existingProduct) {
        if (existingProduct.quantity < product.quantity) {
          return prevCart.map((item) =>
            item.id === product.id
              ? { ...item, quantity: item.quantity + 1 }
              : item
          );
        } else {
          alert(`No more ${product.name} available!`);
          return prevCart;
        }
      } else {
        return [...prevCart, { ...product, quantity: 1 }];
      }
    });

    setProducts((prevProducts) =>
      prevProducts.map((item) =>
        item.id === product.id ? { ...item, quantity: item.quantity - 1 } : item
      )
    );
  };

  const updateQuantity = (id, quantity) => {
    if (quantity < 1) return;

    setCart((prevCart) =>
      prevCart.map((item) =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (id) => {
    const itemToRemove = cart.find((item) => item.id === id);

    setProducts((prevProducts) =>
      prevProducts.map((product) =>
        product.id === id
          ? { ...product, quantity: product.quantity + itemToRemove.quantity }
          : product
      )
    );

    setCart((prevCart) => prevCart.filter((item) => item.id !== id));
  };

  const getTotalPrice = () => {
    return cart.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    ).toFixed(2);
  };

  const filteredProducts = products.filter((product) =>
    (selectedCategory === 'All' || product.category === selectedCategory) &&
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = ['All', 'Fruits', 'Vegetables', 'Groceries', 'Snacks'];

  // Login/Signup Forms
  const loginForm = (
    <div className="login-form">
      <h2>Login</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
      <p>Don't have an account? <span onClick={() => setIsSignup(true)}>Sign up</span></p>
    </div>
  );

  const signupForm = (
    <div className="signup-form">
      <h2>Sign Up</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleSignup}>Sign Up</button>
      <p>Already have an account? <span onClick={() => setIsSignup(false)}>Login</span></p>
    </div>
  );

  if (!isLoggedIn) {
    return isSignup ? signupForm : loginForm;
  }

  return (
    <div className="app">
      <header className="header-container">
        <h1>Grocery Store</h1>
        <div className="search-container">
          <input
            type="text"
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>
      </header>

      {/* Category Buttons */}
      <div className="category-buttons">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={selectedCategory === category ? 'active' : ''}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Product List */}
      <div className="product-list">
        {filteredProducts.map((product) => (
          <div key={product.id} className="product-item">
            <img src={product.image} alt={product.name} className="grocery-image" />
            <h2>{product.name}</h2>
            <p>Price: ₹{product.price.toFixed(2)}</p>
            <p>Quantity: {product.quantity}</p>
            <button
              onClick={() => addToCart(product)}
              className={`add-button ${product.quantity <= 0 ? 'out-of-stock' : ''}`}
              disabled={product.quantity <= 0}
            >
              {product.quantity <= 0 ? 'Out of Stock' : 'Add to Cart'}
            </button>
          </div>
        ))}
      </div>

      {/* Shopping Cart */}
      <div className="cart">
        <h2 className="cart-title">Shopping Cart</h2>
        {cart.length === 0 ? (
          <p>Your cart is empty</p>
        ) : (
          <div>
            {cart.map((item) => (
              <div key={item.id} className="cart-item">
                <img src={item.image} alt={item.name} className="cart-image" />
                <div className="cart-details">
                  <p className="cart-name">{item.name}</p>
                  <p className="cart-price">₹{item.price.toFixed(2)}</p>
                </div>
                <div>
                  <input
                    type="number"
                    value={item.quantity}
                    min="1"
                    max={products.find((prod) => prod.id === item.id)?.quantity}
                    onChange={(e) =>
                      updateQuantity(item.id, parseInt(e.target.value))
                    }
                  />
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="delete-button"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
            <h3 className="cart-total">Total Price: ₹{getTotalPrice()}</h3>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
